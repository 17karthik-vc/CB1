import customtkinter as ctk
from tkinter import messagebox
from PIL import Image
import os
import tkinter.filedialog as fd
import nltk
from nltk.tokenize import word_tokenize
from fuzzywuzzy import process
import firebase_admin
from firebase_admin import credentials, firestore
import datetime
import socket

nltk.download('punkt')

def is_connected():
    try:
        socket.create_connection(("8.8.8.8", 53), timeout=3)
        return True
    except OSError:
        return False

# Initialize Firebase
cred = credentials.Certificate("config/instaclone-c92a2-firebase-adminsdk-fbsvc-65bad9b6e9.json")
firebase_admin.initialize_app(cred)
db = firestore.client()

# Cyberbullying words

cyberbullying_words = {
    "racist", "sexist", "homophobic", "nazi", "terror", "slavery", "genocide",
    "idiot", "stupid", "dumb", "ugly", "loser", "moron", "worthless", "pathetic", "garbage", "scoundral", "rascal",
    "kill", "hurt", "burn", "punch", "stab", "die", "destroy", "attack", "harm",
    "nude", "rape", "molest", "harass", "pervert", "creep", "sugar daddy","sex", "fuck",
    "suicide", "depression","jeevan",
}

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

# ------------------ Authentication ------------------
class InstagramAuth(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Instagram Clone - Login")
        self.geometry("350x500")
        self.attributes("-fullscreen", True)
        self.create_login_ui()

    def create_login_ui(self):
        for widget in self.winfo_children():
            widget.destroy()
        ctk.CTkLabel(self, text="CyPost Login",text_color= "white",font=("Arial", 40, "bold")).pack(pady=20)
        self.username_entry = ctk.CTkEntry(self, placeholder_text="Username",width=250)
        self.username_entry.pack(pady=10, padx=20)
        self.password_entry = ctk.CTkEntry(self, placeholder_text="Password", show="*",width=250)
        self.password_entry.pack(pady=10, padx=20)
        ctk.CTkButton(self, text="Login", command=self.login).pack(pady=10)
        ctk.CTkButton(self, text="Create an Account", fg_color="gray", command=self.create_signup_ui).pack(pady=5)
        ctk.CTkButton(self, text="❌ Close App", fg_color="black", hover_color="darkgray", command=self.close_app).pack(padx=10)

    def create_signup_ui(self):
        for widget in self.winfo_children():
            widget.destroy()
        ctk.CTkLabel(self, text="CyPost Sign Up", font=("Arial", 40, "bold")).pack(pady=20)
        self.new_username_entry = ctk.CTkEntry(self, placeholder_text="Username",width=250)
        self.new_username_entry.pack(pady=10, padx=20)
        self.new_password_entry = ctk.CTkEntry(self, placeholder_text="Password", show="*",width=250)
        self.new_password_entry.pack(pady=10, padx=20)
        ctk.CTkButton(self, text="Sign Up", command=self.signup).pack(pady=10)
        ctk.CTkButton(self, text="Back to Login", fg_color="gray", command=self.create_login_ui).pack(pady=5)
        ctk.CTkButton(self, text="❌ Close App", fg_color="black", hover_color="darkgray", command=self.close_app).pack(padx=10)

    def close_app(self):
        if messagebox.askyesno("Confirm", "Are you sure you want to close the app?"):
            self.destroy()
            exit()

    def signup(self):
        username = self.new_username_entry.get().strip()
        password = self.new_password_entry.get().strip()
        if not username or not password:
            messagebox.showerror("Error", "All fields are required!")
            return
        if db.collection('users').document(username).get().exists:
            messagebox.showerror("Error", "Username already exists!")
            return
        db.collection('users').document(username).set({
            "username": username,
            "password": password
        })
        messagebox.showinfo("Success", "Account Created! Please Login.")
        self.create_login_ui()

    def login(self):
        username = self.username_entry.get().strip().rstrip("/")
        password = self.password_entry.get().strip()
        if not username or not password:
            messagebox.showerror("Error", "Username and Password cannot be empty!")
            return
        doc = db.collection('users').document(username).get()
        if doc.exists and doc.to_dict().get("password") == password:
            if not is_connected():
                messagebox.showerror("Network Error", "Please connect to the internet to log in.")
                return
            messagebox.showinfo("Success", "Login Successful!")
            self.destroy()
            InstagramClone(username)
        else:
            messagebox.showerror("Error", "Invalid Credentials!")

# ------------------ Search Window ------------------
class SearchWindow(ctk.CTkToplevel):
    def __init__(self):
        super().__init__()
        self.title("Search Users")
        self.geometry("400x300")
        self.resizable(False, False)
        self.grab_set()
        ctk.CTkLabel(self, text="Search Users", font=("Arial", 16, "bold")).pack(pady=10)
        self.search_entry = ctk.CTkEntry(self, placeholder_text="Enter username...")
        self.search_entry.pack(pady=10, padx=20)
        ctk.CTkButton(self, text="Search", command=self.perform_search).pack(pady=5)
        self.results_frame = ctk.CTkFrame(self)
        self.results_frame.pack(pady=10, padx=20, fill="both", expand=True)
        ctk.CTkButton(self, text="Close", fg_color="red", command=self.destroy).pack(pady=5)

    def perform_search(self):
        for widget in self.results_frame.winfo_children():
            widget.destroy()
        query = self.search_entry.get().strip().lower()
        if not query:
            messagebox.showwarning("Warning", "Enter a search term!")
            return
        results = []
        for doc in db.collection('users').get():
            user = doc.to_dict().get("username", "")
            if query in user.lower():
                results.append(user)
        if results:
            for user in results:
                ctk.CTkButton(self.results_frame, text=user, font=("Arial", 12),
                              command=lambda u=user: self.open_user_profile(u)).pack(pady=2)
        else:
            ctk.CTkLabel(self.results_frame, text="No users found.", font=("Arial", 12, "bold")).pack(pady=5)

    def open_user_profile(self, username):
        profile_window = ProfilePage(username)
        profile_window.grab_set()

# ------------------ Main Feed ------------------
class InstagramClone(ctk.CTk):
    def __init__(self, username):
        super().__init__()
        self.username = username
        self.title("Instagram Clone")
        self.geometry("400x600")
        self.resizable(False, False)
        self.attributes("-fullscreen", True)
        self.create_welcome_message()
        self.scroll_frame = ctk.CTkScrollableFrame(self, width=380, height=500)
        self.scroll_frame.pack(pady=(5,10), padx=10, fill="both", expand=True)
        self.load_posts()
        self.create_navbar()
        self.check_connection()
        self.mainloop()

    def create_welcome_message(self):
        frame = ctk.CTkFrame(self, fg_color="gray", height=50)
        frame.pack(side="top", fill="x")
        ctk.CTkLabel(frame, text=f"Welcome, {self.username}!", font=("Arial", 16, "bold")).pack(side="left", padx=10, pady=5)
        ctk.CTkButton(frame, text="Logout", fg_color="red", hover_color="darkred", command=self.logout).pack(side="right", padx=10)

    def check_connection(self):
        if not is_connected():
            messagebox.showwarning("Network Issue", "You are offline. Some features may not work.")
        self.after(10000, self.check_connection)

    def load_posts(self):
        for widget in self.scroll_frame.winfo_children():
            widget.destroy()
        posts_docs = db.collection('posts').order_by("timestamp", direction=firestore.Query.DESCENDING).get()
        for doc in posts_docs:
            post = doc.to_dict()
            post_id = doc.id
            frame = ctk.CTkFrame(self.scroll_frame, corner_radius=15)
            frame.pack(pady=10, padx=10, fill="x")
            ctk.CTkLabel(frame, text=post.get('username', ""), font=("Arial", 14, "bold")).pack(anchor="w", padx=10, pady=5)
            # Display caption if available
            caption = post.get('caption', "")
            if caption:
                ctk.CTkLabel(frame, text=f"Caption: {caption}", font=("Arial", 12)).pack(anchor="w", padx=10)
            image_path = post.get('image_path', "home.png")
            if os.path.exists(image_path):
                pil_img = Image.open(image_path).resize((300, 300))
                ctk_img = ctk.CTkImage(light_image=pil_img, size=(300,300))
                img_label = ctk.CTkLabel(frame, image=ctk_img, text="")
                img_label.image = ctk_img
                img_label.pack()
            # Like section
            like_frame = ctk.CTkFrame(frame)
            like_frame.pack(pady=5)
            like_count = post.get('like_count', 0)
            like_button = ctk.CTkButton(like_frame, text="❤️ Like", fg_color="red", hover_color="darkred",
                                        command=lambda pid=post_id, ll=None: self.like_post(pid, ll))
            like_label = ctk.CTkLabel(like_frame, text=f"Likes: {like_count}", font=("Arial", 12, "bold"))
            like_button.configure(command=lambda pid=post_id, ll=like_label: self.like_post(pid, ll))
            like_button.pack(side="left")
            like_label.pack(side="left", padx=(5, 0))
            # Delete button for user's own posts
            if post.get('username', "") == self.username:
                ctk.CTkButton(frame, text="Delete Post", fg_color="red", hover_color="darkred",
                              command=lambda pid=post_id: self.delete_post(pid)).pack(pady=5)
            # Comment section with username display
            ce = ctk.CTkEntry(frame, placeholder_text="Add a comment...", width=250)
            ce.pack(pady=5)
            cl = ctk.CTkLabel(frame, text="", wraplength=300, anchor="w", justify="left")
            cl.pack(pady=5)
            comments = post.get('comments', [])
            display_text = "\n".join([
                f"{c.get('username', 'Unknown')}: {c.get('comment', '')}" if isinstance(c, dict) else str(c)
                for c in comments
            ])
            cl.configure(text=display_text)
            def add_comment(pid=post_id, comments=comments, ce=ce, cl=cl):
                new_comment = ce.get().strip()
                if not new_comment:
                    messagebox.showwarning("Warning", "Comment cannot be empty!")
                    return
                for word in word_tokenize(new_comment.lower()):
                    match, score = process.extractOne(word, cyberbullying_words)
                    if score >= 80:
                        messagebox.showwarning("Warning", f"Inappropriate word detected: '{word}' (similar to '{match}')")
                        return
                comment_data = {"username": self.username, "comment": new_comment}
                db.collection('posts').document(pid).update({
                    'comments': firestore.ArrayUnion([comment_data])
                })
                comments.append(comment_data)
                messagebox.showinfo("Success", "Comment added successfully!")
                display_text = "\n".join([f"{c.get('username', 'Unknown')}: {c.get('comment', '')}" for c in comments])
                cl.configure(text=display_text)
                ce.delete(0, "end")
            ctk.CTkButton(frame, text="Comment", fg_color="blue", hover_color="darkblue", command=add_comment).pack(pady=5)

    def delete_post(self, post_id):
        if messagebox.askyesno("Confirm Delete", "Are you sure you want to delete this post?"):
            db.collection('posts').document(post_id).delete()
            messagebox.showinfo("Success", "Post deleted successfully!")
            self.load_posts()

    def like_post(self, post_id, like_label):
        db.collection('posts').document(post_id).update({
            'like_count': firestore.Increment(1)
        })
        updated_post = db.collection('posts').document(post_id).get().to_dict()
        new_like_count = updated_post.get('like_count', 0)
        like_label.configure(text=f"Likes: {new_like_count}")

    def create_navbar(self):
        navbar = ctk.CTkFrame(self, height=50, fg_color="black")
        navbar.pack(side="bottom", fill="x")
        ctk.CTkButton(navbar, text="🏠 Home", fg_color="blue", hover_color="darkblue", width=120,
                      command=self.load_posts).pack(side="left", expand=True)
        ctk.CTkButton(navbar, text="➕ Upload", fg_color="blue", hover_color="darkblue", width=120,
                      command=self.upload_image).pack(side="left", expand=True)
        ctk.CTkButton(navbar, text="🔍 Search", fg_color="blue", hover_color="darkblue", width=120,
                      command=self.open_search).pack(side="left", expand=True)
        ctk.CTkButton(navbar, text="👤 Profile", fg_color="blue", hover_color="darkblue", width=120,
                      command=self.open_profile).pack(side="left", expand=True)
        ctk.CTkButton(navbar, text="Settings", fg_color="blue", hover_color="darkblue",
                      command=self.settings).pack(side="right", expand=True)
        ctk.CTkButton(navbar, text="❌ Close App", fg_color="blue", hover_color="darkblue",
                      command=self.close_app).pack(side="right", expand=True)

    def open_search(self):
        SearchWindow().grab_set()

    def upload_image(self):
        file_path = fd.askopenfilename(filetypes=[("Image Files", "*.png;*.jpg;*.jpeg")])
        if file_path:
            # Create a new frame for the post upload preview
            frame = ctk.CTkFrame(self.scroll_frame, corner_radius=15)
            frame.pack(pady=10, padx=10, fill="x")
            ctk.CTkLabel(frame, text=f"{self.username}", font=("Arial", 14, "bold")).pack(anchor="w", padx=10, pady=5)
            # Display the selected image
            pil_img = Image.open(file_path).resize((300, 300))
            ctk_img = ctk.CTkImage(light_image=pil_img, size=(300,300))
            img_label = ctk.CTkLabel(frame, image=ctk_img, text="")
            img_label.image = ctk_img
            img_label.pack()
            # Caption entry for the post
            caption_entry = ctk.CTkEntry(frame, placeholder_text="Enter caption...", width=250)
            caption_entry.pack(pady=5)
            # Cyberbullying detection for caption on button click:
            def get_caption():
                cap = caption_entry.get().strip()
                # Check each word in the caption for cyberbullying
                for word in word_tokenize(cap.lower()):
                    match, score = process.extractOne(word, cyberbullying_words)
                    if score >= 80:
                        messagebox.showwarning("Warning", f"Inappropriate word in caption: '{word}' (similar to '{match}')")
                        return None
                return cap
            # Like section for the new post
            like_frame = ctk.CTkFrame(frame)
            like_frame.pack(pady=5)
            like_label = ctk.CTkLabel(like_frame, text="Likes: 0", font=("Arial", 12, "bold"))
            like_label.pack(side="right", padx=(5,0))
            # We'll add the post only when the user clicks "Upload Post"
            def upload_post():
                caption = get_caption()
                if caption is None:
                    return  # Stop if caption failed cyberbullying check
                # Create post data with caption included
                post_data = {
                    'username': self.username,
                    'image_path': file_path,
                    'caption': caption,
                    'comments': [],
                    'timestamp': datetime.datetime.utcnow(),
                    'like_count': 0
                }
                # Save post to Firestore
                write_result, doc_ref = db.collection('posts').add(post_data)
                messagebox.showinfo("Success", "Post uploaded successfully!")
                self.load_posts()
            ctk.CTkButton(frame, text="Upload Post", fg_color="green", hover_color="darkgreen", command=upload_post).pack(pady=5)
            # Optionally, add a comment section preview for the new post after upload if needed.
            # (Typically, the new post will be loaded via self.load_posts() after upload.)

    def close_app(self):
        if messagebox.askyesno("Confirm", "Are you sure you want to close the app?"):
            self.destroy()
            exit()

    def logout(self):
        if messagebox.askyesno("Confirm", "Are you sure you want to logout?"):
            self.destroy()
            InstagramAuth().mainloop()

    def open_profile(self):
        if hasattr(self, "profile_window") and self.profile_window.winfo_exists():
            self.profile_window.lift()
        else:
            self.profile_window = ProfilePage(self.username)
            self.profile_window.grab_set()

    def settings(self):
        if hasattr(self, "profile_window") and self.profile_window.winfo_exists():
            self.profile_window.lift()
        else:
            self.profile_window = SettingsPage(self.username)
            self.profile_window.grab_set()

# ------------------ Settings Page ------------------
class SettingsPage(ctk.CTkToplevel):
    def __init__(self, username):
        super().__init__()
        self.username = username
        self.title(f"{username}'s Settings")
        self.geometry("400x600")
        self.resizable(False, False)
        self.attributes("-fullscreen", True)
        sidebar = ctk.CTkFrame(self, width=80, corner_radius=0)
        sidebar.pack(side="left", fill="y")
        ctk.CTkLabel(sidebar, text="Settings", font=("Arial", 14, "bold")).pack(pady=10, padx=10)
        ctk.CTkButton(sidebar, text="Close", fg_color="red", command=self.destroy).pack(pady=10, padx=10, fill="x")

# ------------------ Profile Page ------------------
class ProfilePage(ctk.CTkToplevel):
    def __init__(self, username):
        super().__init__()
        self.username = username
        self.title(f"{username}'s Profile")
        self.geometry("400x600")
        self.resizable(False, False)
        self.attributes("-fullscreen", True)
        ctk.CTkLabel(self, text=f"Profile: {self.username}", font=("Arial", 18, "bold")).pack(pady=20)
        self.profile_pic_label = ctk.CTkLabel(self, text="No Profile Picture", width=100, height=100, fg_color="gray")
        self.profile_pic_label.pack(pady=10)
        ctk.CTkButton(self, text="Upload Profile Picture", command=self.upload_profile_pic).pack(pady=5)
        self.display_bio = ctk.CTkLabel(self, text="", font=("Arial", 12, "bold"), wraplength=300)
        self.display_bio.pack(pady=5)
        self.bio_text = ctk.CTkEntry(self, placeholder_text="Write something about yourself...", width=300)
        self.bio_text.pack(pady=5)
        self.load_profile()
        ctk.CTkButton(self, text="Save Bio", command=self.save_bio).pack(pady=5)
        ctk.CTkButton(self, text="Close", fg_color="red", command=self.destroy).pack(pady=10)
        ctk.CTkLabel(self, text="Your Posts:", font=("Arial", 14, "bold")).pack(pady=10)
        self.post_list_frame = ctk.CTkScrollableFrame(self, width=380, height=150)
        self.post_list_frame.pack(pady=5, padx=10, fill="both", expand=True)
        self.load_user_posts()

    def load_profile(self):
        doc = db.collection('profiles').document(self.username).get()
        bio = ""
        profile_pic_path = ""
        if doc.exists:
            data = doc.to_dict()
            bio = data.get('bio', "")
            profile_pic_path = data.get('profile_pic', "")
        self.bio_text.delete(0, "end")
        self.bio_text.insert(0, bio)
        self.display_bio.configure(text=f"Bio: {bio}")
        if profile_pic_path and os.path.exists(profile_pic_path):
            pil_img = Image.open(profile_pic_path).resize((100, 100))
            ctk_img = ctk.CTkImage(light_image=pil_img, size=(100,100))
            self.profile_pic_label.configure(image=ctk_img, text="")
            self.profile_pic_label.image = ctk_img
        else:
            self.profile_pic_label.configure(text="No Profile Picture", image="")

    def save_bio(self):
        user_bio = self.bio_text.get().strip()
        if not user_bio:
            messagebox.showwarning("Warning", "Bio cannot be empty!")
            return
        db.collection('profiles').document(self.username).set({'bio': user_bio}, merge=True)
        messagebox.showinfo("Success", "Bio updated successfully!")
        self.load_profile()

    def upload_profile_pic(self):
        file_path = fd.askopenfilename(filetypes=[("Image Files", "*.png;*.jpg;*.jpeg")])
        if file_path:
            db.collection('profiles').document(self.username).set({'profile_pic': file_path}, merge=True)
            messagebox.showinfo("Success", "Profile picture updated!")
            self.load_profile()

    def load_user_posts(self):
        for widget in self.post_list_frame.winfo_children():
            widget.destroy()
        posts_docs = db.collection('posts').where("username", "==", self.username)\
                         .order_by("timestamp", direction=firestore.Query.DESCENDING).get()
        if posts_docs:
            for doc in posts_docs:
                post = doc.to_dict()
                image_path = post.get('image_path', None)
                if image_path and os.path.exists(image_path):
                    pil_img = Image.open(image_path).resize((100, 100))
                    ctk_img = ctk.CTkImage(light_image=pil_img, size=(100,100))
                    lbl = ctk.CTkLabel(self.post_list_frame, image=ctk_img, text="")
                    lbl.image = ctk_img
                    lbl.pack(side="left", padx=5, pady=5)
                else:
                    lbl = ctk.CTkLabel(self.post_list_frame, text="No Image", width=100, height=100, fg_color="gray")
                    lbl.pack(side="left", padx=5, pady=5)
        else:
            ctk.CTkLabel(self.post_list_frame, text="No posts yet.", font=("Arial", 12, "bold")).pack()

# Run the Application
app = InstagramAuth()
app.mainloop()
